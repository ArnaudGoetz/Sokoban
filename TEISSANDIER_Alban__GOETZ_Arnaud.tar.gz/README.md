# Sokoban
Vous trouverez ici les fichiers de base pour le TP noté concernant le jeu du Sokoban.

Les consignes et l'énoncé se trouvent à cette addresse [TP Sokoban](https://techdevprintemps2022.pages.unistra.fr/TP_TechDevEnonce/)

La branche main est celle de la partie 1 du projet, la partie 2 est sur la branche "partie2".

Version de gcc utilisée :
gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0

TEISSANDIER Alban
GOETZ Arnaud
